global.comprado_carcara = false;
global.equipado_carcara = false;
preco = 10;
image_speed = 0;


