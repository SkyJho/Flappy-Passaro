if (global.pontuacao_2 == 20) {
	image_index = 1;
	global.pontuacao_2 -= 20;
	object_set_sprite(obj_player, spr_coruja)
}