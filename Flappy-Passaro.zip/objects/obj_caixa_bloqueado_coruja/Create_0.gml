image_speed = 0;

if (global.pontuacao_2 >= 20) image_index = 2;